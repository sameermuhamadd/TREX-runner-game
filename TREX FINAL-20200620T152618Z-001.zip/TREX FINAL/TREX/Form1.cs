﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.IO;
namespace TREX
{
    public partial class Form1 : Form
    {

        bool landed = true;
        int gravity = 30;
        int score = 0;
        int tempScore = 0;
        int platformSpeed = 15;
        int DownLimit = 405;
        Random rnd = new Random();
        bool jump = false;
        int life = 3;
        public int MaxLimit = 150;
        // bool intersect = false;
        int pingscore = 0;
        public static int gscore = 0;
        bool sound = false;
        PictureBox collideWith;
        bool Day = true;
        public static string scorewrite = "";

        Form2 highscore;
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void Reset()
        {
            landed = true;
            jump = false;
            player.Image = Properties.Resources.batman_1;
            lblFscore.Visible = false;
            lblAgain.Visible = false;
            gravity = 30;
            score = 0;
            life = 3;
            platformSpeed = 15;
            DownLimit = 405;
            rnd = new Random();
            MaxLimit = 150;
            timer1.Start();
            Stone1.Left = 871;
            Stone2.Left = 546;
            coin.Left = 700;
            pingscore = 0;

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                score++;
                tempScore++;
                if (tempScore > 700)
                {
                    if (Day)
                    {
                        BackgroundImage = Properties.Resources.backgroundnight;
                        Day = false;
                    }
                    else
                    {
                        BackgroundImage = Properties.Resources.background;
                        Day = true;
                    }
                    tempScore = 0;
                }

                if (player.Bottom >= platform.Top)
                {
                    landed = true;
                }
                else
                {
                    if (jump)
                    {
                        player.Top -= gravity;
                    }
                    else
                    {
                        player.Top += gravity - 12;
                    }

                }

                if (player.Top <= MaxLimit)
                {
                    jump = false;
                }


                MoveStones();
                Collision();
                //UpdateAll();
                scoreLabel.Text = "Score :" + score;
                pingSound();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }



        //private void UpdateAll()
        //{
        //    try
        //    {
        //       // scoreLabel.Text = "Score :" + score;
        //        foreach (Control score1 in this.Controls)
        //        {
        //            if (score1 is Label)
        //            {
        //        //        score1.Update();
        //                //scoreLabel.Text = "Score :" + score;
        //          //      scoreLabel.Update();
        //            }
        //        }
        //    }
        //    catch (Exception error)
        //    {
        //        MessageBox.Show(error.Message);
        //    }
        //}

        private void Collision()
        {
            try
            {
                label2.Text = "Lives: " + life;
                if ((player.Bounds.IntersectsWith(Stone1.Bounds) || player.Bounds.IntersectsWith(Stone2.Bounds)) && life >= 1)
                {
                    PictureBox tempCollideWith = player.Bounds.IntersectsWith(Stone1.Bounds) ? Stone1 : Stone2;
                    if (tempCollideWith == collideWith)
                    {
                        // Collide with same stone
                    }
                    else
                    {
                                    life--;
                    }

                    collideWith = player.Bounds.IntersectsWith(Stone1.Bounds) ? Stone1 : Stone2;

                    if (life < 1)
                    {
                        gscore = score;
                        timer1.Stop();
                        player.Image = Properties.Resources.stop;
                        lblFscore.Text = "GAME OVER! HIGHSCORE: " + score;
                        lblFscore.Visible = true;
                        lblAgain.Visible = true;
                        //DialogResult result = MessageBox.Show("Game Over! Restart?", "Game Over", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        //if (result == DialogResult.Yes)
                        //{
                        //    Reset();
                        //}
                        //else
                        //{
                        //    Application.Exit();
                        //}
                    }
                }

                if (player.Bounds.IntersectsWith(coin.Bounds))
                {
                    score += 10;
                    tempScore += 10;
                    pingscore += 10;
                    //if (coin is PictureBox)
                    //{
                    //    this.Controls.Remove(coin);
                    //}
                }
            }

            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void MoveStones()
        {
            try
            {
                foreach (Control stone in this.Controls)
                {
                    if (stone is PictureBox && stone.Tag == "Stone")
                    {

                        if (stone.Right <= this.Left)
                        {
                            stone.Left = this.Right;
                        }
                        stone.Left -= platformSpeed;

                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Space && !jump && landed)
                {
                    jump = true;
                    player.Top -= gravity;
                    landed = false;
                }
                if (e.KeyCode == Keys.R)
                {
                    Reset();
                }
                if (e.KeyCode == Keys.Escape)
                {
                    Application.Exit();
                }

            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        private void pingSound()
        {
            try
            {

                pingscore++;
                if (pingscore > 100)
                {
                    SoundPlayer ping = new SoundPlayer("ping.wav");
                    ping.Play();
                    pingscore = 0;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

        }

        public void scoreSave()
        {
            try
            {

                StreamWriter sw = new StreamWriter("Highscore.txt", true);
                sw.WriteLine(score);    
                sw.Close();
                StreamReader sr = new StreamReader("Highscore.txt");
                while (sr.ReadLine() != null)
                {
                        scorewrite = sr.ReadToEnd();    
                }
               // gscore = Convert.ToInt32(scorewrite);
                sr.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }



        private void scoreBtn_Click(object sender, EventArgs e)
        {
            try
            {
                scoreSave();
                timer1.Stop();
                highscore = new Form2();
                highscore.Show();
                this.Hide();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
