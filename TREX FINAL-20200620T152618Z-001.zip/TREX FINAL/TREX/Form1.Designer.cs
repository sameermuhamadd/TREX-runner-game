﻿namespace TREX
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.scoreLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.player = new System.Windows.Forms.PictureBox();
            this.platform = new System.Windows.Forms.PictureBox();
            this.Stone1 = new System.Windows.Forms.PictureBox();
            this.Stone2 = new System.Windows.Forms.PictureBox();
            this.coin = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.scoreBtn = new System.Windows.Forms.Button();
            this.lblFscore = new System.Windows.Forms.Label();
            this.lblAgain = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.platform)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Stone1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Stone2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).BeginInit();
            this.SuspendLayout();
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.BackColor = System.Drawing.Color.Transparent;
            this.scoreLabel.Font = new System.Drawing.Font("Paytone One", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.Location = new System.Drawing.Point(11, 9);
            this.scoreLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(50, 23);
            this.scoreLabel.TabIndex = 2;
            this.scoreLabel.Text = "Score";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(400, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 3;
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // player
            // 
            this.player.BackColor = System.Drawing.Color.Transparent;
            this.player.Image = global::TREX.Properties.Resources.batman_1;
            this.player.Location = new System.Drawing.Point(111, 328);
            this.player.Margin = new System.Windows.Forms.Padding(2);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(94, 124);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 4;
            this.player.TabStop = false;
            // 
            // platform
            // 
            this.platform.BackColor = System.Drawing.Color.Transparent;
            this.platform.Location = new System.Drawing.Point(9, 448);
            this.platform.Margin = new System.Windows.Forms.Padding(2);
            this.platform.Name = "platform";
            this.platform.Size = new System.Drawing.Size(751, 26);
            this.platform.TabIndex = 7;
            this.platform.TabStop = false;
            // 
            // Stone1
            // 
            this.Stone1.BackColor = System.Drawing.Color.Transparent;
            this.Stone1.Image = ((System.Drawing.Image)(resources.GetObject("Stone1.Image")));
            this.Stone1.Location = new System.Drawing.Point(418, 409);
            this.Stone1.Margin = new System.Windows.Forms.Padding(2);
            this.Stone1.Name = "Stone1";
            this.Stone1.Size = new System.Drawing.Size(31, 44);
            this.Stone1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Stone1.TabIndex = 8;
            this.Stone1.TabStop = false;
            this.Stone1.Tag = "Stone";
            // 
            // Stone2
            // 
            this.Stone2.BackColor = System.Drawing.Color.Transparent;
            this.Stone2.Image = ((System.Drawing.Image)(resources.GetObject("Stone2.Image")));
            this.Stone2.Location = new System.Drawing.Point(614, 395);
            this.Stone2.Margin = new System.Windows.Forms.Padding(2);
            this.Stone2.Name = "Stone2";
            this.Stone2.Size = new System.Drawing.Size(30, 58);
            this.Stone2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Stone2.TabIndex = 9;
            this.Stone2.TabStop = false;
            this.Stone2.Tag = "Stone";
            // 
            // coin
            // 
            this.coin.BackColor = System.Drawing.Color.Transparent;
            this.coin.Image = ((System.Drawing.Image)(resources.GetObject("coin.Image")));
            this.coin.Location = new System.Drawing.Point(527, 422);
            this.coin.Margin = new System.Windows.Forms.Padding(2);
            this.coin.Name = "coin";
            this.coin.Size = new System.Drawing.Size(31, 30);
            this.coin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin.TabIndex = 10;
            this.coin.TabStop = false;
            this.coin.Tag = "Stone";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Paytone One", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 23);
            this.label2.TabIndex = 11;
            this.label2.Text = "Lives\r\n";
            // 
            // scoreBtn
            // 
            this.scoreBtn.Location = new System.Drawing.Point(9, 70);
            this.scoreBtn.Name = "scoreBtn";
            this.scoreBtn.Size = new System.Drawing.Size(104, 31);
            this.scoreBtn.TabIndex = 30;
            this.scoreBtn.TabStop = false;
            this.scoreBtn.Text = "View Scores";
            this.scoreBtn.UseVisualStyleBackColor = true;
            this.scoreBtn.Click += new System.EventHandler(this.scoreBtn_Click);
            // 
            // lblFscore
            // 
            this.lblFscore.AutoSize = true;
            this.lblFscore.BackColor = System.Drawing.Color.Transparent;
            this.lblFscore.Font = new System.Drawing.Font("Permanent Marker", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFscore.Location = new System.Drawing.Point(175, 237);
            this.lblFscore.Name = "lblFscore";
            this.lblFscore.Size = new System.Drawing.Size(339, 35);
            this.lblFscore.TabIndex = 31;
            this.lblFscore.Text = "GAME OVER! HIGHSCORE";
            this.lblFscore.Visible = false;
            // 
            // lblAgain
            // 
            this.lblAgain.AutoSize = true;
            this.lblAgain.BackColor = System.Drawing.Color.Transparent;
            this.lblAgain.Font = new System.Drawing.Font("Permanent Marker", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgain.Location = new System.Drawing.Point(253, 272);
            this.lblAgain.Name = "lblAgain";
            this.lblAgain.Size = new System.Drawing.Size(196, 22);
            this.lblAgain.TabIndex = 32;
            this.lblAgain.Text = "Press \"R\" To Play Again!";
            this.lblAgain.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackgroundImage = global::TREX.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 547);
            this.Controls.Add(this.lblAgain);
            this.Controls.Add(this.lblFscore);
            this.Controls.Add(this.scoreBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.coin);
            this.Controls.Add(this.Stone2);
            this.Controls.Add(this.Stone1);
            this.Controls.Add(this.platform);
            this.Controls.Add(this.player);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scoreLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "RUNNER GAME";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.platform)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Stone1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Stone2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.PictureBox platform;
        private System.Windows.Forms.PictureBox Stone1;
        private System.Windows.Forms.PictureBox Stone2;
        private System.Windows.Forms.PictureBox coin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button scoreBtn;
        private System.Windows.Forms.Label lblFscore;
        private System.Windows.Forms.Label lblAgain;
    }
}

